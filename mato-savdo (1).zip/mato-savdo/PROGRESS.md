# Loyiha holati

**Loyiha:** mato-savdo — mato sotuvchilar uchun SaaS (sklad, sotuv, nasiya, analitika)
**Hujjatlar tili:** o'zbekcha
**Oxirgi yangilanish:** 2026-10-02

## Bosqichlar
| # | Bosqich | Holat |
|---|---------|-------|
| 1 | Biznes maqsadi | ✅ |
| 2 | Loyiha tavsifi | ✅ |
| 3 | Detallar | ✅ (00-09) |
| 4 | Skelet | ✅ |
| 5 | Baza va kod | 🔨 5.2 · 00-core (sxema ✅) |

## Hozirgi joy
Bosqich 5.2 · 00-core · 1-qadam: loyiha asosi fayllari berildi (tasdiq kutilmoqda) → 2-qadam: 1-migratsiya

## Modullar (5-bosqich)
| # | Modul | Holat | Izoh |
|---|-------|-------|------|
| 00 | core | 🔨 | 1-qadam: loyiha asosi (fayllar tayyor) |
| 01-10 | — | ⏳ | |

## Qabul qilingan qarorlar
- 2026-10-01 Mahsulot SaaS (multi-tenant) — ko'plab mato sotuvchilarga sotiladi.
- 2026-10-01 1-versiya pilot mijoz bilan; obuna to'lovlari keyin.
- 2026-10-01 Tovar partiya bo'yicha hisoblanadi (har rulon emas) — rulonga alohida etiketka amaliy emas.
- 2026-10-01 Partiyani sotuvchi yopadi; kamomad yopilganda hisoblanadi.
- 2026-10-01 Sotuv narxiga cheklov yo'q — javobgarlik sotuvchida.
- 2026-10-01 Valyuta: so'm.
- 2026-10-01 Omborchi roli qo'shildi; biznes egasi barcha huquqlarga ega.
- 2026-10-01 Qoldiq va partiya yopish har joy bo'yicha alohida (biznesdan tasdiqlanguncha).
- 2026-10-01 Qaytarish 1-versiyada; chek kerak emas; kassa yopish keyinroq.
- 2026-10-01 Bildirishnomalar tizim ichida + Telegram bot.
- 2026-10-01 Kirish: telefon + parol (SMS yo'q); do'kon qurilmasida sotuvchilar 4 xonali PIN bilan.
- 2026-10-01 Interfeys 3 tilda: uz (lotin), en, ru.
- 2026-10-01 Do'kon qurilmasi: ism-familiya doim ko'rinadi, qulf tugmasi, avto-qulflash 30 daq (sozlanadi).
- 2026-10-01 Harakatlar jurnali kategoriyalar bo'yicha; o'zgartirib bo'lmaydi.
- 2026-10-01 Rollar qat'iy (4 ta); sotuvchi tannarxni ko'rmaydi.
- 2026-10-01 Bizneslarni faqat platforma egasi qo'shadi; platforma admini 2FA bilan.
- 2026-10-01 Biznes hech qachon o'chirilmaydi, faqat bloklanadi; kunlik zaxira nusxa.
- 2026-10-01 Do'kon va sklad interfeysda alohida; do'konda ham qoldiq bor.
- 2026-10-01 Sotuvchining do'konlari tanlanadi (barchasi yoki tanlanganlari); sotuvchiga telefon shart emas.
- 2026-10-01 Do'kon qurilmasida faqat PIN bilan kirish (ism tanlanmaydi); istalgan PIN ruxsat, faol sotuvchilar orasida noyob. Xavf: "PIN band" xabari boshqa sotuvchi PIN'ini oshkor qilishi mumkin — yechim: PIN'ni faqat biznes egasi o'rnatadi.
- 2026-10-01 Bir nechta biznes egasi: bitta asosiy ega + sherik-egalar (teng huquq, faqat egalarni boshqara olmaydi). Asosiy egani faqat platforma egasi almashtiradi.
- 2026-10-01 Katalog: kodlar erkin (biznes o'zi yaratadi); SKU kirimda avtomatik; tavsiya narx har SKU uchun bitta (ulgurji/chakana yo'q), keyingi partiyalarda saqlanadi; narx kg yoki metrda, ekvivalent avtomatik; koeffitsient matoda standart, partiyada o'zgartiriladi; ommaviy narx qo'yish/o'zgartirish.
- 2026-10-01 Kirim faqat skladga; tannarx 1 metr uchun; yetkazib beruvchi yozilmaydi; harakatsiz kirim tahrirlanadi, harakatli — faqat ega.
- 2026-10-01 Omborchi tannarxni kiritadi va kirimda ko'radi; foyda unga yopiq.
- 2026-10-01 Qoldiq metrda (rulon taxminiy); ko'chirish ikki bosqichli (jo'natish → qabul); manfiy qoldiqda izoh bilan sotish; partiyani qayta ochish — ega yoki omborchi; sotuvchi boshqa joylar qoldig'ini ko'radi; inventarizatsiya keyin.
- 2026-10-01 Sotuv: narx 1 metr uchun, jami avtomatik; tavsiya narx tugmasi; qo'lda tanlashda eng eski partiya; to'lov — naqd/karta/nasiya; qaytarishni sotuvchi qiladi, pul qaytadi, muddatsiz; sotuvchi 10 daqiqa ichida bekor qiladi; qaytarishlar egaga tizim xabari + jurnal (Telegram emas).
- 2026-10-01 Nasiya: boshlang'ich to'lov bor; to'lov eng eski qarzga; limit yo'q; mijoz telefoni majburiy; qarzni hisobdan chiqarishni sotuvchi ham qiladi (egaga tizim xabari).
- 2026-10-01 Hisobotlar: foyda = savdo − tannarx (bitta); Excel eksport; o'tgan davr bilan taqqoslash; top tovarlar; sotuvchilar kesimi hisoboti keyin.
- 2026-10-01 Bildirishnomalar: 10 hodisa; Telegram — darhol faqat 5, 7, 10; kunlik xulosa 21:00; har ega Telegram'ni o'zi sozlaydi.
- 2026-10-01 Telegram bot alohida 10-modul, eng oxirida quriladi; tizim ichidagi xabarlar (09) asosiy modullar bilan birga.
- 2026-10-01 Sahifalar xaritasi tasdiqlandi; qo'shildi: sotuvlar ro'yxati, sotuv kartochkasi (06), partiya kartochkasi (05).
- 2026-10-01 Sotuv ekrani: bitta ustun — kiritish qatori, ostida ro'yxat, pastda to'lov.
- 2026-10-01 Barcha eskizlar tasdiqlandi (docs/04-eskizlar.md). Kod yozish CLAUDE.md qoidalari bo'yicha.
- 2026-10-01 Interfeysda "kamomad" o'rniga "Metr farqi" (kam chiqdi / ortiq chiqdi) — docs/atamalar.md.
- 2026-10-01 Stek: FastAPI + SQLAlchemy 2 + Alembic, PostgreSQL (+RLS), Redis + navbat, SSE (real vaqt), React + TypeScript + Vite (PWA), Tailwind, i18next, Docker Compose.
- 2026-10-01 Barcha papka nomlari inglizcha (modules/00-core ..., docs/03-details, docs/sketches).
- 2026-10-02 Baza sxemasi tasdiqlandi (32 jadval, ikki qatlamli qoldiq, RLS har jadvalda, sessions, counters, due_date).
- 2026-10-01 Omborchi skladlarini biznes egasi belgilaydi (barchasi yoki tanlanganlari).

## Ochiq savollar
- Biznesdan so'raladigan savollar → docs/biznesdan-savollar.md
