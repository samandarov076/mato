# mato-savdo

Mato sotuvchilar uchun SaaS: sklad (partiyalar), sotuv, nasiya, hisobotlar. Web + PWA, 3 til (uz, en, ru).

## Stek
FastAPI · SQLAlchemy 2 · Alembic · PostgreSQL (RLS) · Redis · SSE · React + TypeScript + Vite (PWA) · Tailwind · i18next · Docker Compose

## Tuzilma
- `docs/` — tasdiqlangan talablar, xarita, eskizlar, atamalar
- `modules/` — modullar xaritasi (har modulga README)
- `backend/` — FastAPI ilova
- `frontend/` — React ilova
- `PROGRESS.md` — loyiha holati va qarorlar
- `CLAUDE.md` — AI uchun ish qoidalari

## Modullar
| # | Modul | Holat |
|---|-------|-------|
| 00 | core | ⏳ |
| 01 | platform-admin | ⏳ |
| 02 | structure | ⏳ |
| 03 | catalog | ⏳ |
| 04 | receiving | ⏳ |
| 05 | inventory | ⏳ |
| 06 | sales | ⏳ |
| 07 | credit | ⏳ |
| 08 | reports | ⏳ |
| 09 | notifications | ⏳ |
| 10 | telegram | ⏳ |

## Ishga tushirish (ishlab chiqish)

Talablar: Docker, Python 3.12+, Node.js 20+.

```bash
cp .env.example .env
docker compose up -d                 # PostgreSQL va Redis

cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
uvicorn app.main:app --reload        # http://localhost:8000/api/health

cd ../frontend
npm install
npm run dev                          # http://localhost:5173
```

Migratsiyalar (2-qadamdan boshlab): `cd backend && alembic upgrade head`
