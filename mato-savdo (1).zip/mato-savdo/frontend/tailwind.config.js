/** Dizayn tokenlari dashboard eskizidan (docs/sketches/dashboard.html). */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        indigo: { DEFAULT: "#23306B", 2: "#3A4A96", soft: "#E6E9F5" },
        madder: { DEFAULT: "#A8323E", soft: "#F7E6E8" },
        saffron: { DEFAULT: "#9A6A07", soft: "#FBF1DA" },
        leaf: { DEFAULT: "#2F6B45", soft: "#E3F1E8" },
        ink: "#1A1D29",
        muted: "#646A7E",
        line: "#DCE0EA",
        page: "#F6F7FB",
        panel: "#FFFFFF",
      },
      fontFamily: { sans: ['"Golos Text"', "system-ui", "sans-serif"] },
      borderRadius: { card: "14px" },
    },
  },
  plugins: [],
};
