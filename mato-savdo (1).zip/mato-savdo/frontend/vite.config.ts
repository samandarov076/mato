import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      manifest: {
        name: "mato-savdo",
        short_name: "mato-savdo",
        description: "Mato savdosi: sklad, sotuv, nasiya, hisobotlar",
        lang: "uz",
        start_url: "/",
        display: "standalone",
        background_color: "#F6F7FB",
        theme_color: "#23306B",
        icons: [
          { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
          { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
        ],
      },
      workbox: {
        // API javoblari keshlanmaydi — qoldiq va narx doim serverdan
        navigateFallbackDenylist: [/^\/api\//],
      },
    }),
  ],
  server: {
    port: 5173,
    proxy: { "/api": "http://localhost:8000" },
  },
});
