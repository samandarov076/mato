import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { api } from "@/shared/api/client";

/** Vaqtinchalik sahifa: backend va baza ulanganini ko'rsatadi. 6-qadamda o'rniga kirish sahifasi keladi. */
export function HealthPage() {
  const { t } = useTranslation();
  const q = useQuery({ queryKey: ["health"], queryFn: () => api<{ status: string; db: string }>("/health") });

  return (
    <div className="rounded-card border border-line bg-panel p-6">
      <h1 className="text-xl font-semibold">{t("app_name")}</h1>
      <p className="mt-2 text-muted">{t("health.title")}</p>
      <p className="mt-4 text-sm">
        {q.isLoading && t("health.checking")}
        {q.isError && <span className="text-madder">{t("health.error")}</span>}
        {q.data && <span className="text-leaf">{t("health.ok")}</span>}
      </p>
    </div>
  );
}
