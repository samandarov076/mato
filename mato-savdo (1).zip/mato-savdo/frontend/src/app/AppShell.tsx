import { Outlet } from "react-router-dom";
import { useTranslation } from "react-i18next";

/** Ilova qobig'i. 6-qadamda rol bo'yicha menyu va yuqori panel shu yerga keladi. */
export function AppShell() {
  const { t, i18n } = useTranslation();
  return (
    <div className="min-h-screen">
      <header className="flex items-center gap-4 border-b border-line bg-panel px-6 py-3">
        <span className="font-semibold text-indigo">mato-savdo</span>
        <span className="flex-1" />
        <select
          aria-label={t("language")}
          className="rounded-md border border-line bg-panel px-2 py-1 text-sm"
          value={i18n.resolvedLanguage}
          onChange={(e) => i18n.changeLanguage(e.target.value)}
        >
          <option value="uz">O'zbekcha</option>
          <option value="en">English</option>
          <option value="ru">Русский</option>
        </select>
      </header>
      <main className="mx-auto max-w-5xl p-6">
        <Outlet />
      </main>
    </div>
  );
}
