import { createBrowserRouter } from "react-router-dom";
import { AppShell } from "./AppShell";
import { HealthPage } from "./HealthPage";

/** Marshrutlar. Har modul o'z sahifalarini shu yerga qo'shadi. */
export const router = createBrowserRouter([
  {
    path: "/",
    element: <AppShell />,
    children: [{ index: true, element: <HealthPage /> }],
  },
]);
