import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import LanguageDetector from "i18next-browser-languagedetector";
import uz from "@/locales/uz/common.json";
import en from "@/locales/en/common.json";
import ru from "@/locales/ru/common.json";

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: { uz: { common: uz }, en: { common: en }, ru: { common: ru } },
    fallbackLng: "uz",
    supportedLngs: ["uz", "en", "ru"],
    defaultNS: "common",
    interpolation: { escapeValue: false },
    detection: { order: ["localStorage", "navigator"], caches: ["localStorage"] },
  });

export default i18n;
