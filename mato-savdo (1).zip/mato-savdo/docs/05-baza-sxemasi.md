# Baza sxemasi

PostgreSQL. Jadval va ustun nomlari inglizcha. Biznesga tegishli har jadvalda `business_id` + Row-Level Security.

## Turlar
| Ma'lumot | Tur | Sabab |
|----------|-----|-------|
| Pul (so'm) | `bigint` | butun son, yaxlitlash xatosi yo'q |
| Metr | `numeric(12,2)` | 1 sm aniqlik |
| Kg | `numeric(12,3)` | 1 g aniqlik |
| Koeffitsient (1 kg = X m) | `numeric(10,4)` | — |
| Vaqt | `timestamptz` | UTC'da saqlanadi, Asia/Tashkent'da ko'rsatiladi |
| Id | `bigint` (identity) | — |

## 1. Platforma va kirish (00-core, 01-platform-admin)

```mermaid
erDiagram
  BUSINESSES ||--o{ USERS : "xodimlari"
  BUSINESSES ||--o{ BUSINESS_STATUS_EVENTS : "bloklash tarixi"
  USERS ||--o{ USER_LOCATIONS : "ruxsat etilgan joylar"
  USERS ||--o{ RECOVERY_CODES : "2FA zaxira kodlari"
  BUSINESSES ||--o{ DEVICES : "do'kon qurilmalari"
  BUSINESSES ||--o{ AUDIT_LOGS : "jurnal"
  USERS ||--o{ SESSIONS : "faol sessiyalar"
  BUSINESSES ||--o{ COUNTERS : "raqam ketma-ketliklari"
  BUSINESSES {
    bigint id PK
    text name
    text status "active | blocked"
    bool sell_by_kg
    bool credit_enabled
    int credit_days "30"
    numeric low_stock_default
    int price_rounding "1 | 100 | 1000"
    int autolock_minutes "30"
    time daily_summary_time "21:00"
    text timezone "Asia/Tashkent"
    timestamptz created_at
    timestamptz last_activity_at
  }
  USERS {
    bigint id PK
    bigint business_id FK "platforma egasida NULL"
    text full_name
    text phone UK "sotuvchida NULL"
    text password_hash
    text pin_hash "faqat sotuvchi"
    text role "platform_owner | owner | warehouse | seller"
    bool is_primary_owner
    bool all_locations
    text totp_secret "faqat platforma egasi"
    text language "uz | en | ru"
    bool must_change_password
    bool is_active
  }
  USER_LOCATIONS {
    bigint user_id FK
    bigint location_id FK
  }
  DEVICES {
    bigint id PK
    bigint business_id FK
    bigint store_id FK
    text name
    text token_hash
    timestamptz last_seen_at
    timestamptz revoked_at
  }
  AUDIT_LOGS {
    bigint id PK
    bigint business_id FK
    bigint user_id FK
    bigint location_id FK
    text category "login | sale | stock | price | credit | staff"
    text event_code
    jsonb data "eski va yangi qiymatlar"
    timestamptz created_at
  }
  BUSINESS_STATUS_EVENTS {
    bigint id PK
    bigint business_id FK
    text action "block | unblock | owner_change"
    text reason
    timestamptz created_at
  }
  RECOVERY_CODES {
    bigint user_id FK
    text code_hash
    timestamptz used_at
  }
  SESSIONS {
    bigint id PK
    bigint business_id FK
    bigint user_id FK
    bigint device_id FK "do'kon qurilmasida"
    text refresh_token_hash
    timestamptz expires_at
    timestamptz revoked_at
  }
  COUNTERS {
    bigint business_id PK
    text name PK "batch | sale | transfer | receipt"
    bigint value
  }
```

- Platforma egasi `users` jadvalida, `business_id = NULL`, `role = platform_owner`.
- PIN faqat faol sotuvchilar orasida noyob — qisman noyob indeks: `(business_id, pin_lookup) WHERE role='seller' AND is_active`.
- `audit_logs` faqat qo'shiladi; yangilash va o'chirish trigger bilan taqiqlanadi (ilova bitta baza foydalanuvchisi bilan ishlagani uchun ruxsatlar yetarli emas).
- `sessions` — xodim faolsizlantirilganda yoki qurilma uzilganda **darhol** chiqarish uchun: har sessiya bazada, tekshirilganda `revoked_at` ko'riladi. Busiz JWT muddati tugaguncha xodim ishlayveradi.
- `counters` — P-000123, S-000045, K-00045 kabi raqamlar har biznes uchun alohida va uzluksiz; qator qulflanib oshiriladi (ketma-ketlikda bo'shliq qolmaydi).
- `users.phone` — qisman noyob indeks `WHERE phone IS NOT NULL`.

## 2. Tuzilma va katalog (02-structure, 03-catalog)

```mermaid
erDiagram
  LOCATIONS ||--o{ DEVICES : "do'konda"
  FABRICS ||--o{ SKUS : ""
  COLORS ||--o{ SKUS : ""
  PATTERNS ||--o{ SKUS : ""
  SKUS ||--o{ SKU_PRICE_HISTORY : "narx tarixi"
  LOCATIONS {
    bigint id PK
    bigint business_id FK
    text type "store | warehouse"
    text name
    text address
    text phone
    bool is_active
  }
  FABRICS {
    bigint id PK
    bigint business_id FK
    text code UK "biznes ichida"
    text name
    int width_cm
    text composition
    text image_url
    numeric default_m_per_kg
    bool is_active
  }
  COLORS {
    bigint id PK
    bigint business_id FK
    bigint fabric_id FK "NULL = umumiy ro'yxat"
    text code
    text name
    text image_url
    bool is_active
  }
  PATTERNS {
    bigint id PK
    bigint business_id FK
    bigint fabric_id FK "NULL = umumiy ro'yxat"
    text code
    text name
    text image_url
    bool is_active
  }
  SKUS {
    bigint id PK
    bigint business_id FK
    bigint fabric_id FK
    bigint color_id FK
    bigint pattern_id FK
    bigint price "tavsiya narx, so'm"
    text price_unit "m | kg"
    numeric low_stock_threshold
    bool is_active
  }
  SKU_PRICE_HISTORY {
    bigint id PK
    bigint sku_id FK
    bigint old_price
    bigint new_price
    text price_unit
    bigint user_id FK
    timestamptz created_at
  }
```

- Do'kon va sklad interfeysda alohida, bazada bitta `locations` jadvali (`type` bilan) — qoldiq, ko'chirish va yopish ikkalasida bir xil ishlaydi.
- `colors.fabric_id` va `patterns.fabric_id` NULL bo'lsa — umumiy ro'yxat; to'ldirilsa — faqat shu matoniki. Biznes savoliga (ranglar umumiymi yoki matoniki) qanday javob kelsa ham sxema o'zgarmaydi.
- "Gulsiz" — oddiy `patterns` yozuvi, har biznesga avtomatik yaratiladi.
- SKU noyob: `(business_id, fabric_id, color_id, pattern_id)`.
- Rang/gul kodi noyob: `(business_id, fabric_id, code)` — `fabric_id` NULL bo'lganda ham ishlashi uchun `UNIQUE NULLS NOT DISTINCT` (PostgreSQL 15+).

## 3. Kirim va ombor (04-receiving, 05-inventory) — tizimning yuragi

```mermaid
erDiagram
  RECEIPTS ||--|{ BATCHES : "partiyalar"
  SKUS ||--o{ BATCHES : ""
  BATCHES ||--o{ BATCH_STOCK : "joylar bo'yicha qoldiq"
  LOCATIONS ||--o{ BATCH_STOCK : ""
  BATCHES ||--o{ STOCK_MOVEMENTS : "har bir harakat"
  LOCATIONS ||--o{ STOCK_MOVEMENTS : ""
  TRANSFERS ||--|{ TRANSFER_LINES : ""
  BATCHES ||--o{ TRANSFER_LINES : ""
  BATCH_STOCK ||--o{ BATCH_CLOSURES : "yopilishlar"
  RECEIPTS {
    bigint id PK
    bigint business_id FK
    bigint warehouse_id FK
    date receipt_date
    text note
    text status "active | cancelled"
    bigint created_by FK
  }
  BATCHES {
    bigint id PK
    bigint business_id FK
    bigint receipt_id FK
    bigint sku_id FK
    text number UK "P-000123"
    int rolls_count
    numeric meters_labeled "etiketka bo'yicha"
    numeric kg
    numeric m_per_kg
    bigint cost_per_m "tannarx"
  }
  BATCH_STOCK {
    bigint batch_id PK
    bigint location_id PK
    numeric received_m "shu joyga kirgan"
    numeric qty_m "hozirgi qoldiq, manfiy bo'lishi mumkin"
    text status "open | closed"
  }
  STOCK_MOVEMENTS {
    bigint id PK
    bigint business_id FK
    bigint batch_id FK
    bigint location_id FK
    numeric qty_m "+ kirdi, - chiqdi"
    text type "receipt | receipt_cancel | transfer_out | transfer_in | transfer_cancel | sale | sale_cancel | return | close | reopen | correction"
    text ref_type
    bigint ref_id
    bigint user_id FK
    text note
    timestamptz created_at
  }
  TRANSFERS {
    bigint id PK
    bigint business_id FK
    bigint from_location_id FK
    bigint to_location_id FK
    text status "in_transit | received | cancelled"
    bigint sent_by FK
    timestamptz sent_at
    bigint received_by FK
    timestamptz received_at
    text note
  }
  TRANSFER_LINES {
    bigint id PK
    bigint transfer_id FK
    bigint batch_id FK
    int sent_rolls
    numeric sent_m
    int received_rolls
    numeric received_m
    text diff_note
  }
  BATCH_CLOSURES {
    bigint id PK
    bigint batch_id FK
    bigint location_id FK
    numeric received_m
    numeric out_m
    numeric diff_m "+ kam chiqdi, - ortiq chiqdi"
    bigint diff_amount "so'm, tannarx bo'yicha"
    bigint closed_by FK
    timestamptz closed_at
    bigint reopened_by FK
    timestamptz reopened_at
    text note
  }
```

- **Ikki qatlam:** `stock_movements` — hech qachon o'zgarmaydigan harakatlar jurnali (haqiqat manbai, partiya kartochkasidagi tarix shundan). `batch_stock` — hozirgi qoldiq; har harakat bilan **bitta tranzaksiyada** yangilanadi. Sotuvda faqat shu bitta qator qulflanadi (`SELECT ... FOR UPDATE`) — boshqa partiya va do'konlar kutmaydi.
- Tekshiruv: `batch_stock.qty_m` = shu partiya-joy bo'yicha `stock_movements.qty_m` yig'indisi. Kechasi avtomatik solishtiriladi; farq chiqsa — platforma egasiga xabar.
- Yo'ldagi tovar: `transfer_out` jo'natuvchidan ayiradi, `transfer_in` qabulda qo'shadi; oraliqda metr `transfer_lines` da turadi.
- Partiya yopilganda `close` harakati qoldiqni 0 ga keltiradi, farq `batch_closures` ga yoziladi. Qayta ochishda `reopen` buni bekor qiladi.
- **Ko'chirishda yo'qolgan metr** (jo'natilgan 500, qabul qilingan 488) joylar qoldig'iga kirmaydi — faqat `transfer_lines` da turadi va "Metr farqi" hisobotida alohida qatorda ko'rinadi. Shunda u partiya yopilganda ikkinchi marta hisoblanmaydi.
- **Qoldiqni faqat bitta funksiya o'zgartiradi** (`inventory.service.move_stock`): u `stock_movements` ga yozadi va `batch_stock` ni bitta tranzaksiyada yangilaydi. Boshqa hech qayerda `batch_stock` to'g'ridan-to'g'ri o'zgartirilmaydi.
- **Kam qoldiq tekshiruvi** sotuvdan keyin fonda: SKU-joy bo'yicha `batch_stock` yig'indisi chegara bilan solishtiriladi (indeks: `batch_stock (location_id, batch_id)` + `batches (sku_id)`). Alohida kesh jadvali kerak emas.

## 4. Sotuv va nasiya (06-sales, 07-credit)

```mermaid
erDiagram
  SALES ||--|{ SALE_LINES : "qatorlar"
  SALES ||--o{ SALE_RETURNS : "qaytarishlar"
  SALE_RETURNS ||--|{ RETURN_LINES : ""
  SALE_LINES ||--o{ RETURN_LINES : ""
  CUSTOMERS ||--o{ SALES : "nasiya"
  SALES ||--o| DEBTS : "nasiya bo'lsa"
  CUSTOMERS ||--o{ DEBTS : ""
  CUSTOMERS ||--o{ DEBT_PAYMENTS : ""
  DEBT_PAYMENTS ||--|{ PAYMENT_ALLOCATIONS : "qaysi qarzlarga"
  DEBTS ||--o{ PAYMENT_ALLOCATIONS : ""
  DEBTS ||--o{ DEBT_WRITEOFFS : "hisobdan chiqarish"
  SALES {
    bigint id PK
    bigint business_id FK
    uuid client_uuid UK "takrorlanishdan himoya"
    bigint store_id FK
    bigint seller_id FK
    bigint device_id FK
    bigint customer_id FK
    bigint total
    text payment_type "cash | card | credit"
    bigint initial_payment
    text initial_payment_method "cash | card"
    text status "completed | cancelled"
    bigint cancelled_by FK
    text cancel_reason
    timestamptz created_at
  }
  SALE_LINES {
    bigint id PK
    bigint sale_id FK
    bigint batch_id FK
    bigint sku_id FK
    text sku_label "sotuv paytidagi nom"
    numeric meters
    numeric kg
    bigint price_per_m "haqiqiy"
    bigint recommended_price_per_m "tavsiya"
    bigint cost_per_m "tannarx nusxasi"
    bigint amount
    numeric returned_m
    text negative_stock_note
  }
  SALE_RETURNS {
    bigint id PK
    bigint sale_id FK
    bigint store_id FK
    bigint user_id FK
    bigint amount
    text method "cash | card | debt"
    timestamptz created_at
  }
  RETURN_LINES {
    bigint return_id FK
    bigint sale_line_id FK
    numeric meters
    bigint amount
  }
  CUSTOMERS {
    bigint id PK
    bigint business_id FK
    text name
    text phone UK "biznes ichida"
    text note
    bool is_active
  }
  DEBTS {
    bigint id PK
    bigint business_id FK
    bigint customer_id FK
    bigint sale_id FK
    bigint amount
    bigint paid
    bigint written_off
    bigint returned
    date due_date "yaratilganda credit_days bo'yicha"
    text status "active | cancelled"
    timestamptz created_at
  }
  DEBT_PAYMENTS {
    bigint id PK
    bigint business_id FK
    bigint customer_id FK
    bigint store_id FK
    bigint user_id FK
    bigint amount
    text method "cash | card"
    timestamptz created_at
  }
  PAYMENT_ALLOCATIONS {
    bigint payment_id FK
    bigint debt_id FK
    bigint amount
  }
  DEBT_WRITEOFFS {
    bigint id PK
    bigint debt_id FK
    bigint amount
    text reason
    bigint user_id FK
    timestamptz created_at
  }
```

- **Sotuv qatorida nusxalar:** nom, tavsiya narx va tannarx sotuv paytidagi qiymat bilan saqlanadi. Keyin katalogda narx yoki nom o'zgarsa ham eski sotuvlar, foyda va narx og'ishi hisoboti buzilmaydi.
- **Qarz har sotuvdan alohida** (`debts`). Qolgan qarz = amount − paid − written_off − returned. `due_date` qarz yaratilganda hisoblanadi — keyin biznes `credit_days` ni o'zgartirsa, eski qarzlar siljimaydi. Sotuv bekor qilinsa qarz `cancelled`.
- **To'lov taqsimoti** (`payment_allocations`): bitta to'lov bir nechta eski qarzni yopishi mumkin; har biriga qancha tushgani saqlanadi.
- `client_uuid` — sotuv ekrani yaratadi; server bir xil uuid'ni ikki marta qabul qilmaydi.

## 5. Xabarlar va hisobotlar (09-notifications, 08-reports, 10-telegram)

```mermaid
erDiagram
  USERS ||--o{ NOTIFICATIONS : "qabul qiluvchi"
  USERS ||--o| TELEGRAM_LINKS : "10-modul"
  NOTIFICATIONS {
    bigint id PK
    bigint business_id FK
    bigint user_id FK
    text event_code
    jsonb data
    text dedup_key "takrorlanmaslik uchun"
    timestamptz read_at
    timestamptz created_at
  }
  DAILY_SUMMARY {
    bigint id PK
    bigint business_id FK
    date day
    bigint store_id FK
    bigint seller_id FK
    bigint sales_amount
    bigint returns_amount
    bigint cost_amount
    bigint cash_in
    bigint card_in
    bigint credit_given
    bigint credit_paid
    bigint credit_written_off
    numeric meters_sold
    int sales_count
  }
  TELEGRAM_LINKS {
    bigint user_id PK
    bigint chat_id
    bool daily_summary
    bool instant_alerts
  }
```

- `daily_summary` — noyob `(business_id, day, store_id, seller_id)`; har sotuv, qaytarish va to'lovda shu kun qatori yangilanadi (`INSERT ... ON CONFLICT DO UPDATE`). Haqiqiy jadvallardan qayta hisoblab chiqadigan buyruq bo'ladi. Hisobotlar va dashboard katta jadvallarni emas, shuni o'qiydi — oylar o'tsa ham tez.
- Soatlik trend va top tovarlar `sale_lines` dan indekslar bilan olinadi.
- `notifications.dedup_key` — masalan kam qoldiq xabari bir SKU-joy uchun qayta to'ldirilguncha bir marta.

## Row-Level Security (RLS)
- **Har jadvalda `business_id`** — bog'liq jadvallarda ham (`sale_lines`, `transfer_lines`, `return_lines`, `payment_allocations`, `batch_stock`, `batch_closures`, `sku_price_history`, `user_locations`, `sessions`). Shunda RLS siyosati hamma joyda bir xil: `business_id = current_setting('app.business_id')::bigint`.
- Har so'rov boshida `SET LOCAL app.business_id = ...` (tranzaksiya ichida — ulanishlar puli bilan xavfsiz).
- Platforma egasi uchun RLS'siz alohida baza roli; u biznes ma'lumotlariga kirmaydi (01-modul).
- Ilova kodi `business_id` ni unutsa ham baza boshqa biznes ma'lumotini qaytarmaydi — bu ikkinchi himoya qatlami.

## Indekslar (asosiylari)
- Har jadvalda `business_id` bilan boshlanadigan indekslar
- `sales (business_id, created_at)`, `sales (business_id, store_id, created_at)`
- `sale_lines (sku_id)`, `sale_lines (batch_id)`
- `stock_movements (batch_id, location_id, created_at)`
- `debts (business_id, customer_id) WHERE` qolgan qarz > 0
- `batches (business_id, number)`
- `batch_stock (location_id, batch_id)`, `notifications (user_id) WHERE read_at IS NULL`, `sessions (user_id) WHERE revoked_at IS NULL`
- `audit_logs` va `stock_movements` — oy bo'yicha bo'laklash (partitioning) hajm oshganda; hozir kerak emas

## Biznes savollariga bog'liqlik
| Savol | Sxemada |
|-------|---------|
| Partiya bir nechta joyda bo'ladimi | `batch_stock` (partiya, joy) — ha ham, yo'q ham ishlaydi |
| Ranglar umumiymi yoki matoniki | `fabric_id` NULL yoki to'ldirilgan — ikkalasi |
| Rang/gul rasmi | `image_url` ixtiyoriy |
| Kirimda bir nechta partiya | `receipts` → `batches` — ikkalasi |
| Etiketka o'lchami | bazaga ta'sir qilmaydi |

## 2-ko'rib chiqish (2026-10-02) — nima o'zgardi
1. `sessions` jadvali — xodimni va qurilmani darhol chiqarish uchun (busiz JWT muddati tugaguncha ishlayverardi).
2. `counters` — har biznes uchun uzluksiz hujjat raqamlari.
3. Har jadvalda `business_id` — RLS hamma joyda bir xil ishlashi uchun.
4. `debts.due_date` va `debts.status` — muddat qotirib qo'yiladi, bekor qilingan sotuv qarzi ajratiladi.
5. `businesses.timezone` — kelajakda boshqa mamlakatlar uchun, hozir Asia/Tashkent.
6. `stock_movements.type` ga `receipt_cancel`; `batch_closures.note`.
7. `daily_summary` — surrogat PK + noyob indeks (`seller_id` NULL bo'lishi mumkin).
8. Ko'chirishda yo'qolgan metr qayerda turishi aniq yozildi — ikki marta hisoblanmaydi.
9. Rang/gul kodi noyobligi `NULLS NOT DISTINCT` bilan.
10. Qoldiqni o'zgartirish faqat bitta funksiya orqali — qoida.
