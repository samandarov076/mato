# Atamalar: hujjat va interfeys

Hujjatlarda ishlatilgan ba'zi so'zlar foydalanuvchiga tushunarsiz. Interfeysda quyidagi nomlar ishlatiladi.

| Hujjatda | Interfeysda | Ma'nosi |
|----------|-------------|---------|
| Kamomad | **Metr farqi — kam chiqdi** | Partiya yopilganda tizimda qolgan metr: etiketkada yozilgandan kam mato chiqdi (masalan 50 m yozilgan, 48 m chiqdi) |
| Ortiqcha | **Metr farqi — ortiq chiqdi** | Yozilgandan ko'p mato chiqdi (masalan 50 m yozilgan, 52 m chiqdi) |
| Ko'chirish farqi | **Ko'chirish farqi** | Jo'natilgan va qabul qilingan metr orasidagi farq |
| Kamomadlar hisoboti | **Metr farqi hisoboti** | Ikkala farq turi bitta hisobotda |

Kod va baza nomlarida inglizcha atamalar ishlatiladi (masalan shortage / surplus) — bu foydalanuvchiga ko'rinmaydi.
