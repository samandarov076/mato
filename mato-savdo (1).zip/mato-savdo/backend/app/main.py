from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import get_settings
from app.core.db import check_db, engine

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    await check_db()
    yield
    await engine.dispose()


app = FastAPI(title="mato-savdo API", version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health", tags=["tizim"])
async def health() -> dict:
    """Tizim tirikligini tekshirish."""
    await check_db()
    return {"status": "ok", "db": "ok"}


# Modullar routerlari shu yerga qo'shiladi (3-qadamdan boshlab):
# from app.modules.auth.router import router as auth_router
# app.include_router(auth_router, prefix="/api")
