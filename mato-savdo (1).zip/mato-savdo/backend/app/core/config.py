"""Ilova sozlamalari. Qiymatlar .env faylidan o'qiladi (loyiha ildizidagi)."""
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT_DIR = Path(__file__).resolve().parents[3]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=ROOT_DIR / ".env", extra="ignore")

    database_url: str
    redis_url: str = "redis://localhost:6379/0"

    secret_key: str
    access_token_minutes: int = 30
    refresh_token_days: int = 30

    app_timezone: str = "Asia/Tashkent"
    cors_origins: str = "http://localhost:5173"

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
