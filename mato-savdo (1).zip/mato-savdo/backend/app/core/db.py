"""Baza ulanishi.

Asosiy qoida: biznesga tegishli har bir so'rov tranzaksiya ichida
`SET LOCAL app.business_id = <id>` bilan boshlanadi. PostgreSQL'dagi
Row-Level Security siyosatlari aynan shu qiymatga qaraydi — ilova kodi
business_id shartini unutsa ham, baza boshqa biznes ma'lumotini qaytarmaydi.
"""
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from app.core.config import get_settings

settings = get_settings()

engine = create_async_engine(settings.database_url, pool_size=10, max_overflow=20, pool_pre_ping=True)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


class Base(DeclarativeBase):
    """Barcha modellar uchun asos."""


@asynccontextmanager
async def tenant_session(business_id: int | None) -> AsyncIterator[AsyncSession]:
    """Biznes kontekstidagi sessiya.

    business_id=None — platforma egasi uchun (RLS ostidagi jadvallarga kirmaydi,
    faqat businesses va platforma jadvallari bilan ishlaydi).
    """
    async with SessionLocal() as session:
        async with session.begin():
            if business_id is not None:
                # SET LOCAL — faqat shu tranzaksiya uchun; ulanishlar puli bilan xavfsiz
                await session.execute(
                    text("SET LOCAL app.business_id = :bid"), {"bid": str(business_id)}
                )
            yield session


async def check_db() -> bool:
    async with engine.connect() as conn:
        await conn.execute(text("SELECT 1"))
    return True
