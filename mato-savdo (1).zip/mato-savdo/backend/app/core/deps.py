"""FastAPI uchun umumiy bog'liqliklar (dependencies).

3-qadamda (kirish) bu yerga joriy foydalanuvchi, rol va joy tekshiruvlari qo'shiladi.
Hozircha faqat baza sessiyasi.
"""
from collections.abc import AsyncIterator

from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.db import tenant_session


async def get_db(request: Request) -> AsyncIterator[AsyncSession]:
    """So'rovga bog'langan biznes ichida sessiya.

    request.state.business_id ni 3-qadamdagi auth middleware to'ldiradi.
    Hozircha None — ya'ni RLS ostidagi jadvallarga kirilmaydi.
    """
    business_id = getattr(request.state, "business_id", None)
    async with tenant_session(business_id) as session:
        yield session
