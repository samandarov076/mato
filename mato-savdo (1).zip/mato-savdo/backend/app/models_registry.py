"""Barcha modullarning modellari shu yerda import qilinadi — Alembic ularni ko'rishi uchun.

Har yangi modul o'z models.py faylini shu ro'yxatga qo'shadi.
"""
# 2-qadamdan boshlab:
# from app.modules.auth import models as _auth  # noqa: F401
