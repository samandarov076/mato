# 02 — Tuzilma

## Modul nima qiladi
Do'konlar, skladlar, xodimlar (sherik-ega, omborchi, sotuvchi), joylarga biriktirish, do'kon qurilmalari.

## Sahifalar
- Do'konlar
- Skladlar
- Xodimlar
- Do'kon qurilmalari

## Kim ishlatadi
Biznes egasi

## Bog'liqliklar
- **Bog'liq:** 00-core
- **Bunga bog'liq:** 04-receiving, 05-inventory, 06-sales

## Batafsil
`docs/03-details/02-tuzilma.md`

## Kod
- `backend/app/modules/structure/`
- `frontend/src/modules/structure/`

## Holat
⏳ Boshlanmagan
