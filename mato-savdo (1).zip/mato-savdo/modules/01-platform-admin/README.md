# 01 — Platforma admin

## Modul nima qiladi
Platforma egasining paneli: bizneslarni qo'shish, bloklash, asosiy egani almashtirish, 2FA bilan kirish.

## Sahifalar
- Bizneslar ro'yxati
- Biznes qo'shish
- Biznes sahifasi

## Kim ishlatadi
Platforma egasi

## Bog'liqliklar
- **Bog'liq:** 00-core
- **Bunga bog'liq:** —

## Batafsil
`docs/03-details/01-platforma-admin.md`

## Kod
- `backend/app/modules/platform/`
- `frontend/src/modules/platform/`

## Holat
⏳ Boshlanmagan
