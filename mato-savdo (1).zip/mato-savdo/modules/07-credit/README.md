# 07 — Nasiya

## Modul nima qiladi
Mijozlar, nasiya sotuv (boshlang'ich to'lov bilan), qarz to'lovlari (eng eskisidan), qarzni hisobdan chiqarish.

## Sahifalar
- Mijozlar
- Mijoz kartochkasi
- Qarz to'lovi
- Hisobdan chiqarish

## Kim ishlatadi
Sotuvchi, biznes egasi

## Bog'liqliklar
- **Bog'liq:** 00-core, 09-notifications
- **Bunga bog'liq:** 06-sales, 08-reports

## Batafsil
`docs/03-details/07-nasiya.md`

## Kod
- `backend/app/modules/credit/`
- `frontend/src/modules/credit/`

## Holat
⏳ Boshlanmagan
