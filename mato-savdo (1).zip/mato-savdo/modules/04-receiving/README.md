# 04 — Kirim

## Modul nima qiladi
Skladga tovar qabul qilish: kirim hujjati + partiyalar, tannarx (1 metr), etiketka chop etish.

## Sahifalar
- Kirimlar ro'yxati
- Kirim yaratish
- Kirim kartochkasi

## Kim ishlatadi
Omborchi, biznes egasi

## Bog'liqliklar
- **Bog'liq:** 02-structure, 03-catalog
- **Bunga bog'liq:** 05-inventory, 08-reports

## Batafsil
`docs/03-details/04-kirim.md`

## Kod
- `backend/app/modules/receiving/`
- `frontend/src/modules/receiving/`

## Holat
⏳ Boshlanmagan
