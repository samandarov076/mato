# 03 — Katalog

## Modul nima qiladi
Matolar, ranglar, gullar, SKU (mato + rang + gul), tavsiya narx (ommaviy o'rnatish), kg ↔ metr koeffitsienti.

## Sahifalar
- Matolar
- Ranglar va gullar
- SKU ro'yxati
- SKU kartochkasi

## Kim ishlatadi
Biznes egasi, omborchi

## Bog'liqliklar
- **Bog'liq:** 00-core
- **Bunga bog'liq:** 04-receiving, 06-sales, 08-reports

## Batafsil
`docs/03-details/03-katalog.md`

## Kod
- `backend/app/modules/catalog/`
- `frontend/src/modules/catalog/`

## Holat
⏳ Boshlanmagan
