# 05 — Ombor

## Modul nima qiladi
Joylar bo'yicha qoldiq (metrda, harakatlar jurnali), ikki bosqichli ko'chirish, partiyani yopish, metr farqi.

## Sahifalar
- Qoldiq
- Partiya kartochkasi
- Ko'chirish yaratish
- Ko'chirishni qabul qilish
- Ko'chirishlar ro'yxati
- Partiyani yopish
- Metr farqi hisoboti

## Kim ishlatadi
Omborchi, sotuvchi, biznes egasi

## Bog'liqliklar
- **Bog'liq:** 02-structure, 03-catalog, 04-receiving, 09-notifications
- **Bunga bog'liq:** 06-sales, 08-reports

## Batafsil
`docs/03-details/05-ombor.md`

## Kod
- `backend/app/modules/inventory/`
- `frontend/src/modules/inventory/`

## Holat
⏳ Boshlanmagan
