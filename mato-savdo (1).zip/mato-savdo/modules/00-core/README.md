# 00 — Umumiy (core)

## Modul nima qiladi
Tizim poydevori: kirish (telefon + parol, do'kon qurilmasida PIN), rollar va ruxsatlar, biznes sozlamalari, 3 til, harakatlar jurnali.

## Sahifalar
- Kirish
- Qurilmani do'konga bog'lash
- PIN ekrani
- Profil
- Biznes sozlamalari
- Harakatlar jurnali

## Kim ishlatadi
Hamma rollar

## Bog'liqliklar
- **Bog'liq:** —
- **Bunga bog'liq:** Barcha modullar

## Batafsil
`docs/03-details/00-umumiy.md`

## Kod
- `backend/app/core/`
- `backend/app/modules/auth/`
- `frontend/src/modules/auth/`

## Holat
⏳ Boshlanmagan
