# 09 — Bildirishnomalar

## Modul nima qiladi
Tizim ichidagi xabarlar: kam qoldiq, muddati o'tgan nasiya, qaytarish, hisobdan chiqarish, ko'chirish farqi va h.k. Real vaqtda (SSE).

## Sahifalar
- Xabarlar

## Kim ishlatadi
Egalar, qabul qiluvchilar

## Bog'liqliklar
- **Bog'liq:** 00-core
- **Bunga bog'liq:** 05-inventory, 06-sales, 07-credit, 10-telegram

## Batafsil
`docs/03-details/09-bildirishnomalar.md`

## Kod
- `backend/app/modules/notifications/`
- `frontend/src/modules/notifications/`

## Holat
⏳ Boshlanmagan
