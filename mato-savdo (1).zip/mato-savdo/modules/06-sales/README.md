# 06 — Sotuv

## Modul nima qiladi
Do'kon qurilmasidagi sotuv ekrani, naqd/karta/nasiya, qaytarish, 10 daqiqa ichida bekor qilish.

## Sahifalar
- Sotuv ekrani
- Bugungi sotuvlarim
- Sotuvlar ro'yxati
- Sotuv kartochkasi
- Qaytarish

## Kim ishlatadi
Sotuvchi, biznes egasi

## Bog'liqliklar
- **Bog'liq:** 03-catalog, 05-inventory, 07-credit, 09-notifications
- **Bunga bog'liq:** 08-reports

## Batafsil
`docs/03-details/06-sotuv.md`

## Kod
- `backend/app/modules/sales/`
- `frontend/src/modules/sales/`

## Holat
⏳ Boshlanmagan
