# 08 — Hisobotlar

## Modul nima qiladi
Dashboard, savdo/tushum/foyda, soatlar, top tovarlar, qoldiq, nasiyalar, metr farqi, narx og'ishi; Excel eksport, taqqoslash.

## Sahifalar
- Dashboard
- Savdo-tushum-foyda
- Soatlar
- Top tovarlar
- Qoldiq
- Nasiyalar
- Metr farqi
- Narx og'ishi

## Kim ishlatadi
Biznes egasi

## Bog'liqliklar
- **Bog'liq:** 04-receiving, 05-inventory, 06-sales, 07-credit
- **Bunga bog'liq:** 10-telegram (kunlik xulosa)

## Batafsil
`docs/03-details/08-hisobotlar.md`

## Kod
- `backend/app/modules/reports/`
- `frontend/src/modules/reports/`

## Holat
⏳ Boshlanmagan
