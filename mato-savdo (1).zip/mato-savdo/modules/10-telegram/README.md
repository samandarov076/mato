# 10 — Telegram

## Modul nima qiladi
Telegram bot: ulash, darhol xabarlar, kunlik xulosa (21:00), zaxira ogohlantirishi. Eng oxirida quriladi.

## Sahifalar
- Telegram sozlamalari (profil ichida)

## Kim ishlatadi
Egalar, platforma egasi

## Bog'liqliklar
- **Bog'liq:** 08-reports, 09-notifications
- **Bunga bog'liq:** —

## Batafsil
`docs/03-details/09-bildirishnomalar.md`

## Kod
- `backend/app/modules/telegram/`

## Holat
⏳ Boshlanmagan
